import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h2 className="text-2xl font-semibold">Test Automation Dashboard!</h2>
    </div>
  );
};

export default Dashboard;
